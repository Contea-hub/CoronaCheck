package com.ddd.attendance.check.common

enum class UserType {
    DEFAULT, ADMIN, BASIC
}