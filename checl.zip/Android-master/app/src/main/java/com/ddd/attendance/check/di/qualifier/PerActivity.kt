package com.ddd.attendance.check.di.qualifier

import javax.inject.Scope

@Retention(value = AnnotationRetention.RUNTIME)
@Scope
annotation class PerActivity