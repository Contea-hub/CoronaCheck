package com.ddd.attendance.check.data.source.attendance

class AttendanceLocalDataSource