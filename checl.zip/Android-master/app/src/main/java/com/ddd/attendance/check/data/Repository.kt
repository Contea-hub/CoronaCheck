package com.ddd.attendance.check.data

interface Repository {
}