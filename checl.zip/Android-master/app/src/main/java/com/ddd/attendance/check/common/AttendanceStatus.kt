package com.ddd.attendance.check.common

enum class AttendanceStatus {
    START, STOP
}