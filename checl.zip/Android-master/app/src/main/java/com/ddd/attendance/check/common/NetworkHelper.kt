package com.ddd.attendance.check.common

object NetworkHelper {
    const val ERROR_MSG="네트워크 연결을 확인해주시기 바랍니다."
    const val FAILED="failed"
    const val SUCCESS="success"
}