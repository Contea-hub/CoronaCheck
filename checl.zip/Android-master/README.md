## DDD. 팀원들 출석체크를 위한 안드로이드 버전입니다.


### Spec
- Kotlin
- Dagger2
- Coroutine
- AAC ViewModel
- LiveData
- Room
- okhttp3 + Retrofit2
- DataBinding
- AndroidX

### Architecture Pattern
![image](https://github.com/DevelopDesignDayDay/Android/blob/master/Architecture.001.png)

![image](https://github.com/DevelopDesignDayDay/Android/blob/master/ddd-dagger.001.png)

