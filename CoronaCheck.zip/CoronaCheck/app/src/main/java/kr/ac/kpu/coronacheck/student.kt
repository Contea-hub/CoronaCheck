package kr.ac.kpu.coronacheck

class student(val name:String,val number:String,val subject:String,val checking:Boolean){}